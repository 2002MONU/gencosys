<!DOCTYPE html>
<html lang="en">
      <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Admin | Login</title>
      <!-- Meta -->
      <meta name="description" content="aditya-engineers ">
      <meta property="og:title" content="aditya-engineers">
      <meta property="og:description" content="aditya-engineers">
      <meta property="og:type" content="aditya-engineers">
      <link rel="shortcut icon" href="">
      <!-- *************
         ************ CSS Files *************
         ************* -->
      <link rel="stylesheet" href="<?php echo e(asset('dash_assets/fonts/remix/remixicon.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('dash_assets/css/main.min.css')); ?>">
   </head>
   <style>
       .auth-logo img {
    max-width: 191px;
    max-height: 90px;
}
   </style>
   <body class="login-bg">
      <!-- Container starts -->
      <div class="container">
         <!-- Auth wrapper starts -->
         <div class="auth-wrapper">
            <!-- Form starts -->
            <form action="<?php echo e(route('admin.post-login')); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <div class="auth-box">
                  <a href="#" class="auth-logo mb-4  p-2">
                  <img class=" p-2" src="" alt="Login Logo" >
                  </a>
                  <h4 class="mb-4">Admin Login</h4>
                  <?php if(session('success')): ?>
                  <div class="alert bg-success text-white alert-dismissible fade show" role="alert">
                     <?php echo e(session('success')); ?>

                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                  <div class="alert bg-danger text-white alert-dismissible fade show" role="alert">
                     <?php echo e(session('error')); ?>

                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                  <?php endif; ?>
                  <div class="mb-3">
                     <label class="form-label" for="email">Your email <span class="text-danger">*</span></label>
                     <input type="text" id="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your email">
                     <?php if($errors->has('email')): ?>
                     <span class="text-danger" role="alert">
                     <strong><?php echo e($errors->first('email')); ?>.</strong>
                     </span>
                     <?php endif; ?>
                  </div>
                  <div class="mb-2">
                     <label class="form-label" for="pwd">Your password <span class="text-danger">*</span></label>
                     <input type="password" id="pwd" class="form-control" name="password" placeholder="Enter password">
                     <?php if($errors->has('password')): ?>
                     <span class="text-danger" role="alert">
                     <strong><?php echo e($errors->first('password')); ?>.</strong>
                     </span>
                     <?php endif; ?>
                  </div>
                  <div class="mb-3 d-grid gap-2">
                     <button type="submit" class="btn btn-primary">Login</button>
                  </div>
               </div>
            </form>
            <!-- Form ends -->
         </div>
         <!-- Auth wrapper ends -->
      </div>
      <!-- Container ends -->
   </body>
   <script src="<?php echo e(asset('dash_assets/js/jquery.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dash_assets/js/bootstrap.bundle.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dash_assets/js/moment.min.js')); ?>"></script>
</html><?php /**PATH D:\xampp\htdocs\gencosys\resources\views/admin/account/login.blade.php ENDPATH**/ ?>