<!-- filepath: d:\xampp\htdocs\gencosys\resources\views\website\confirmation.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Confirmation | Register</title>
    <link rel="stylesheet" href="<?php echo e(asset('dash_assets/fonts/remix/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dash_assets/css/main.min.css')); ?>">
</head>
<style>
    .auth-logo img {
        max-width: 191px;
        max-height: 90px;
    }
</style>
<body class="login-bg">
    <!-- Container starts -->
    <div class="container">
        <!-- Auth wrapper starts -->
        <div class="auth-wrapper">
            <!-- Form starts -->
            <div class="auth-box">
                <h4 class="mb-4">Confirmation Details</h4>
                <?php if(isset($student) && isset($course)): ?>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Student Details</h5>
                        <p class="card-text"><strong>Name:</strong> <?php echo e($student['first_name']); ?><?php echo e($student['last_name']); ?></p>
                        <p class="card-text"><strong>Email:</strong> <?php echo e($student['email']); ?></p>
                        <p class="card-text"><strong>Mobile:</strong> <?php echo e($student['mobile']); ?></p>
                        <hr>
                        <h5 class="card-title">Selected Course</h5>
                        <p class="card-text"><strong>Course Name:</strong> <?php echo e($course['name']); ?></p>
                        <p class="card-text"><strong>Description:</strong> <?php echo e($course['brief']); ?></p>
                        <p class="card-text"><strong>Fees:</strong> $<?php echo e($course['fees']); ?></p>
                        <div class="d-grid gap-2 mt-4">
                            <form action="<?php echo e(route('register.submit')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                
                                <input type="hidden" name="course_id" value="<?php echo e($course['id']); ?>">
                                <button type="submit" class="btn btn-success">✅ Confirm & Submit</button>
                            </form>
                            <a href="<?php echo e(route('register.step2', $course->id)); ?>" class="btn btn-secondary">🔄 Change Course</a>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <p class="text-danger">No student or course details found. Please go back and complete the previous steps.</p>
                <a href="<?php echo e(route('register.step1')); ?>" class="btn btn-secondary">🔄 Start Over</a>
                <?php endif; ?>
            </div>
        </div>
        <!-- Auth wrapper ends -->
    </div>
    <!-- Container ends -->
</body>
<script src="<?php echo e(asset('dash_assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dash_assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('dash_assets/js/moment.min.js')); ?>"></script>
</html><?php /**PATH D:\xampp\htdocs\gencosys\resources\views/website/confirmation.blade.php ENDPATH**/ ?>