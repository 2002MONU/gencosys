 
<?php $__env->startSection('title'); ?> Admin  <?php $__env->stopSection(); ?>
<?php $__env->startSection('maindashboard'); ?>
<!-- App container starts -->
<!-- App hero header starts -->
<div class="app-hero-header d-flex align-items-center">
   <!-- Breadcrumb starts -->
   <ol class="breadcrumb">
      <li class="breadcrumb-item">
         <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
         <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
      </li>
      <li class="breadcrumb-item text-primary" aria-current="page">
         Dashboard
      </li>
   </ol>
   <!-- Breadcrumb ends -->
</div>
<!-- App Hero header ends -->
<!-- App body starts -->
<div class="app-body">
   <?php if(session('success')): ?>
   <div class="alert bg-success text-white alert-dismissible fade show" role="alert">
      <?php echo e(session('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
   </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   <div class="alert bg-danger text-white alert-dismissible fade show" role="alert">
      <?php echo e(session('error')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
   </div>
   <?php endif; ?>
   <!-- Row starts -->
   <div class="row gx-3">
      <div class="col-xl-3 col-sm-6 col-12">
         <a href="<?php echo e(route('registerStudent')); ?>">
            <div class="card mb-3">
               <div class="card-body">
                  <div class="d-flex align-items-center">
                     <div class="p-2 border border-success rounded-circle me-3">
                        <div class="icon-box md bg-success-subtle rounded-5">
                           <i class="ri-home-4-fill fs-4 text-success"></i>
                        </div>
                     </div>
                     <div class="d-flex flex-column">
                        <h2 class="lh-1"><?php echo e($student); ?></h2>
                        <p class="m-0">Student Form </p>
                     </div>
                  </div>
               </div>
            </div>
         </a>
      </div>
      <div class="col-xl-3 col-sm-6 col-12">
         <a href="<?php echo e(route('courses.index')); ?>">
            <div class="card mb-3">
               <div class="card-body">
                  <div class="d-flex align-items-center">
                     <div class="p-2 border border-primary rounded-circle me-3">
                        <div class="icon-box md bg-primary-subtle rounded-5">
                           
                           <i class="ri-building-line fs-4 text-primary"></i>
                        </div>
                     </div>
                     <div class="d-flex flex-column">
                        <h2 class="lh-1"><?php echo e($course); ?></h2>
                        <p class="m-0">Courses</p>
                     </div>
                  </div>
               </div>
            </div>
         </a>
      </div>
     
      
      
     
   </div>
   <!-- Row ends -->
</div>
<!-- App body ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gencosys\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>